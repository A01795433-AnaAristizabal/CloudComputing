// SumaArreglos.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//donde tenemos dos arreglos llamados A y B de 10 elementos cada uno y deseamos crear un tercer arreglo
//con la sumatoria de cada uno de los elementos en los mismos subíndices.
//Ana Clemencia Aristizábal Londoño
//Cómputo en la nube
//A01795433

#include <iostream>
#include "pch.h"
#include <omp.h>
#include <ctime>

//Definición de constantes y prototipos
#define N 50000 //cantidad de elementos en cada arreglo
#define chunk 1000//cantidad de elementos de cada hilo creado
#define mostrar 100 //cantidad de datos a imprimir

//declaración de prototipos
//función que asigna valores aleatorios a los arreglos
void asignarValoresAleatorios(float arr[]);
//función que imprime los arreglos en pantalla
void imprimirArreglo(float *d);//parametro: un apuntador referencia al arreglo que contiene los datos a imprimir


int main()
{
	std::cout << "******SUMA DE ARREGLOS EN PARALELO*********\n";
	
	//creación de los arreglos
	float a[N], b[N];//Valores aleatorios de N
	float c[N];//almacena los resultados de la suma de a+b
	int i;

	// Semilla para generar números aleatorios
	std::srand(std::time(0));
	//llamado ala función para asignar valores aleatorios en los arreglos a y b
	asignarValoresAleatorios(a);
	asignarValoresAleatorios(b);

	int conjunto = chunk;

	//definición del for en paralelo con los 3 arreglos en área de memoria compartida
	//definicio del tamaño de los conjuntos y el contador i será privado en cada hilo
	#pragma omp parallel for shared(a,b,c,conjunto) private(i) schedule(static,conjunto)
	for (i = 0; i < N; i++)
		c[i] = a[i] + b[i];

	std::cout << "Imprimiendo los primeros "<< mostrar <<" valores del arreglo a: " << std::endl;
	imprimirArreglo(a);
	std::cout << "Imprimiendo los primeros " << mostrar << " valores del arreglo b: " << std::endl;
	imprimirArreglo(b);
	std::cout << "Imprimiendo los primeros " << mostrar << " valores del arreglo c: " << std::endl;
	imprimirArreglo(c);
}

// Función para asignar valores aleatorios al arreglo
void asignarValoresAleatorios(float arr[]) {
	for (int i = 0; i < N; ++i) {
		arr[i] = (std::rand() % 100) + 1; // Valores entre 1 y 100
	}
}

void imprimirArreglo(float *d) {
	for (int x = 0; x < mostrar; x++) {
		std::cout << d[x];
		std::cout <<std::endl;
	}
}
